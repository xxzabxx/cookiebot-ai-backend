"""Utility modules for CookieBot.ai application."""

