"""API modules for CookieBot.ai application."""

