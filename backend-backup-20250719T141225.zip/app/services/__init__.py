"""Service modules for CookieBot.ai application."""

